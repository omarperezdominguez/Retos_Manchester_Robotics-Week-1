from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    generador = Node(
        package='signal_processing',
        executable='signal_generator', # <--- Coincide con setup.py
        name='generador_senal'
    )

    procesador = Node(
        package='signal_processing', # <--- Corregido (antes decía challenge_1)
        executable='process',         # <--- Coincide con setup.py
        name='procesador_senal'
    )

    rqt = Node(
        package='rqt_plot',
        executable='rqt_plot',
        name='rqt_plot',
        arguments=[
            '/signal/data',     # <--- Tópico corregido
            '/proc_signal/data' # <--- Tópico corregido
        ]
    )

    return LaunchDescription([
        generador,
        procesador,
        rqt
    ])
