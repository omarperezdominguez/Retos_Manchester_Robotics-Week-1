import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class procesador_Senal(Node):
    def __init__(self):
        super().__init__('procesador_senal')
        self.subscription=self.create_subscription(
            Float64,
            '/signal/data',
            self.callback_procesador,
            10
        )
        self.publisher_=self.create_publisher(
            Float64,
            '/proc_signal/data',
            10  
        )
        self.get_logger().info('iniciar procesador de senal')

    def callback_procesador(self,msg):
        y_in=msg.data
        y_out=3.0*y_in

        out_msg=Float64()
        out_msg.data=y_out

        self.publisher_.publish(out_msg)

def main(args=None):
    rclpy.init(args=args)
    node=procesador_Senal()     
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
