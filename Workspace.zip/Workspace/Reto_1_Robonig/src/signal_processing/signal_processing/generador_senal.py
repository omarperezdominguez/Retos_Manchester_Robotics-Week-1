import rclpy 
from rclpy.node import Node     
from std_msgs.msg import Float64
import numpy as np 

class generadorSenal(Node):
    def __init__(self):
        super().__init__('generador_senal')
        self.publisher_=self.create_publisher(Float64, '/signal/data',10)
        self.t=0.0
        self.dt=0.01
        self.A=2.0
        self.f=2.0

        self.timer_=self.create_timer(self.dt,self.timer_callback)
        self.get_logger().info('iniciar generador de senal')
    def timer_callback(self):
        self.t += self.dt
        y=self.A*np.sin(2*np.pi*self.f*self.t)
        msg=Float64()
        msg.data=y
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node=generadorSenal()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
